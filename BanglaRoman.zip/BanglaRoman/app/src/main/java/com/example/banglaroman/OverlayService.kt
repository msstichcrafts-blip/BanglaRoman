package com.example.banglaroman

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Foreground service that:
 *  1. shows a movable/resizable selection box over any app,
 *  2. captures the screen (MediaProjection) and crops the box area,
 *  3. runs Bengali OCR when the area changes,
 *  4. shows the romanized text in a bubble next to the box.
 */
class OverlayService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var wm: WindowManager
    private lateinit var ocr: OcrEngine

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null

    private var screenW = 0
    private var screenH = 0
    private var pad = 0

    private var boxView: BoxView? = null
    private lateinit var boxParams: WindowManager.LayoutParams
    private var resultView: LinearLayout? = null
    private lateinit var resultParams: WindowManager.LayoutParams
    private var tvRoman: TextView? = null
    private var tvOrig: TextView? = null
    private var controlView: LinearLayout? = null
    private lateinit var controlParams: WindowManager.LayoutParams

    @Volatile private var region: Rect? = null
    @Volatile private var dragging = false
    private var locked = false
    private var started = false
    private var destroyed = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ocr = OcrEngine(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (started) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            setupCapture(code, data)
            setupOverlay()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        started = true
        startOcrAndLoop()
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- foreground notification

    private fun goForeground() {
        val channelId = "bangla_roman"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Bangla Romanizer", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Bangla Romanizer is running")
            .setContentText("Use the floating Stop button to quit")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------------------------------------------------------- screen capture

    private fun realScreenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val p = Point()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
            Pair(p.x, p.y)
        }
    }

    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!destroyed) main.post { stopSelf() }
            }
        }, main)
        projection = p

        val (w, h) = realScreenSize()
        screenW = w
        screenH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        virtualDisplay = p.createVirtualDisplay(
            "bangla-capture", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * image.width
        val bmp = Bitmap.createBitmap(
            image.width + rowPadding / plane.pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        bmp.copyPixelsFromBuffer(plane.buffer)
        return bmp
    }

    // ---------------------------------------------------------------- overlay UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun overlayParams(w: Int, h: Int, x: Int, y: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
    }

    private fun setupOverlay() {
        pad = dp(24)

        // --- selection box
        val bw = (screenW * 0.85f).toInt()
        val bh = dp(150) + 2 * pad
        boxParams = overlayParams(bw, bh, (screenW - bw) / 2, (screenH * 0.35f).toInt(), true)
        val bv = BoxView(this, pad)
        bv.onGestureStart = { dragging = true }
        bv.onDrag = { dx, dy ->
            boxParams.x = (boxParams.x + dx).coerceIn(0, maxOf(0, screenW - boxParams.width))
            boxParams.y = (boxParams.y + dy).coerceIn(0, maxOf(0, screenH - boxParams.height))
            wm.updateViewLayout(bv, boxParams)
            positionResult()
        }
        bv.onResize = { dw, dh ->
            val minSize = 2 * pad + dp(60)
            boxParams.width = (boxParams.width + dw).coerceIn(minSize, maxOf(minSize, screenW - boxParams.x))
            boxParams.height = (boxParams.height + dh).coerceIn(minSize, maxOf(minSize, screenH - boxParams.y))
            wm.updateViewLayout(bv, boxParams)
            positionResult()
        }
        bv.onGestureEnd = {
            bv.postDelayed({
                updateRegion()
                dragging = false
            }, 150)
        }
        boxView = bv
        wm.addView(bv, boxParams)
        bv.postDelayed({ updateRegion() }, 300)

        // --- result bubble (never overlaps the capture area)
        val rv = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(0xEE10202C.toInt())
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }
        val maxTextWidth = screenW - dp(24) - dp(24)
        val roman = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTypeface(typeface, Typeface.BOLD)
            maxWidth = maxTextWidth
            setTextIsSelectable(false)
        }
        val orig = TextView(this).apply {
            setTextColor(0xFFB0BEC5.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxWidth = maxTextWidth
        }
        rv.addView(roman)
        rv.addView(orig)
        tvRoman = roman
        tvOrig = orig
        resultView = rv
        resultParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            dp(12), 0, false
        )
        wm.addView(rv, resultParams)

        // --- small control bar: drag grip, Lock, Stop
        val cv = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = GradientDrawable().apply {
                setColor(0xF0202B36.toInt())
                cornerRadius = dp(20).toFloat()
            }
        }
        fun chip(label: String): TextView = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val grip = chip("\u2630")
        val lockBtn = chip("Lock")
        val stopBtn = chip("Stop")
        cv.addView(grip)
        cv.addView(lockBtn)
        cv.addView(stopBtn)
        controlParams = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            maxOf(0, screenW - dp(230)), dp(70), true
        )
        var gx = 0f
        var gy = 0f
        grip.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { gx = e.rawX; gy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - gx).toInt()
                    val dy = (e.rawY - gy).toInt()
                    gx += dx
                    gy += dy
                    controlParams.x = (controlParams.x + dx).coerceIn(0, maxOf(0, screenW - cv.width))
                    controlParams.y = (controlParams.y + dy).coerceIn(0, maxOf(0, screenH - cv.height))
                    wm.updateViewLayout(cv, controlParams)
                }
            }
            true
        }
        lockBtn.setOnClickListener {
            locked = !locked
            boxView?.locked = locked
            lockBtn.text = if (locked) "Unlock" else "Lock"
            boxParams.flags = if (locked) {
                boxParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                boxParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            boxView?.let { wm.updateViewLayout(it, boxParams) }
        }
        stopBtn.setOnClickListener { stopSelf() }
        controlView = cv
        wm.addView(cv, controlParams)
    }

    private fun updateRegion() {
        val bv = boxView ?: return
        val loc = IntArray(2)
        bv.getLocationOnScreen(loc)
        region = Rect(loc[0] + pad, loc[1] + pad, loc[0] + bv.width - pad, loc[1] + bv.height - pad)
    }

    private fun positionResult() {
        val rv = resultView ?: return
        if (rv.visibility != View.VISIBLE) return
        rv.measure(
            View.MeasureSpec.makeMeasureSpec(screenW - dp(24), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val rh = rv.measuredHeight
        var y = boxParams.y + boxParams.height + dp(4)
        if (y + rh > screenH - dp(16)) y = boxParams.y - rh - dp(4)
        if (y < dp(24)) y = dp(24)
        resultParams.x = dp(12)
        resultParams.y = y
        wm.updateViewLayout(rv, resultParams)
    }

    private fun showStatus(msg: String) {
        if (destroyed) return
        tvRoman?.text = msg
        tvOrig?.text = ""
        tvOrig?.visibility = View.GONE
        resultView?.visibility = View.VISIBLE
        positionResult()
    }

    private fun showResult(romanized: String?, original: String) {
        if (destroyed) return
        val rv = resultView ?: return
        if (romanized == null) {
            rv.visibility = View.GONE
            return
        }
        tvRoman?.text = romanized
        tvOrig?.text = original
        tvOrig?.visibility = View.VISIBLE
        rv.visibility = View.VISIBLE
        positionResult()
    }

    // ---------------------------------------------------------------- OCR loop

    private fun startOcrAndLoop() {
        scope.launch {
            val ok = ocr.prepare { msg -> main.post { showStatus(msg) } }
            if (!ok) return@launch
            main.post { showStatus("Drag the box over Bengali text") }
            captureLoop()
        }
    }

    private fun signature(crop: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(crop, 64, 32, true)
        val px = IntArray(64 * 32)
        s.getPixels(px, 0, 64, 0, 0, 64, 32)
        if (s !== crop) s.recycle()
        return IntArray(px.size) {
            val p = px[it]
            (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
        }
    }

    private fun difference(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }

    private suspend fun captureLoop() {
        var frame: Bitmap? = null
        var prevSig: IntArray? = null
        var prevRect: Rect? = null
        var lastText = "\u0000"
        while (currentCoroutineContext().isActive) {
            delay(450)
            val img = reader?.acquireLatestImage()
            if (img != null) {
                val old = frame
                frame = try { imageToBitmap(img) } finally { img.close() }
                old?.recycle()
            }
            val f = frame ?: continue
            val rect = region ?: continue
            if (dragging) continue

            val r = Rect(rect)
            if (!r.intersect(0, 0, f.width, f.height) || r.width() < 24 || r.height() < 24) continue

            val crop = Bitmap.createBitmap(f, r.left, r.top, r.width(), r.height())
            val sig = signature(crop)
            val ps = prevSig
            if (ps != null && prevRect == r && difference(ps, sig) < 2.5) {
                crop.recycle()
                continue
            }
            prevSig = sig
            prevRect = Rect(r)

            val text = try { ocr.recognize(crop) } finally { crop.recycle() }
            if (text == lastText) continue
            lastText = text
            val shown = if (text.isBlank()) null else Romanizer.romanize(text)
            main.post { showResult(shown, text) }
        }
    }

    // ---------------------------------------------------------------- cleanup

    override fun onDestroy() {
        destroyed = true
        scope.cancel()
        for (v in listOf<View?>(boxView, resultView, controlView)) {
            if (v != null) try { wm.removeView(v) } catch (_: Exception) { }
        }
        virtualDisplay?.release()
        reader?.close()
        try { projection?.stop() } catch (_: Exception) { }
        ocr.release()
        super.onDestroy()
    }
}

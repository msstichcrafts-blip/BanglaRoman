package com.example.banglaroman

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * The selection frame. Only the padding ring is drawn on, so the inside stays transparent
 * and the screen capture of the inner area never contains the frame itself.
 * Drag anywhere to move; drag the square in the bottom-right corner to resize.
 */
class BoxView(context: Context, private val pad: Int) : View(context) {

    var onGestureStart: (() -> Unit)? = null
    var onDrag: ((dx: Int, dy: Int) -> Unit)? = null
    var onResize: ((dw: Int, dh: Int) -> Unit)? = null
    var onGestureEnd: (() -> Unit)? = null

    var locked: Boolean = false
        set(value) { field = value; invalidate() }

    private var mode = 0 // 0 = none, 1 = drag, 2 = resize
    private var lastX = 0f
    private var lastY = 0f

    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = 0xFF00E5FF.toInt()
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF00E5FF.toInt()
    }

    override fun onDraw(canvas: Canvas) {
        val inset = pad / 2f
        border.alpha = if (locked) 110 else 255
        canvas.drawRect(inset, inset, width - inset, height - inset, border)
        if (!locked) {
            canvas.drawRect((width - pad).toFloat(), (height - pad).toFloat(), width.toFloat(), height.toFloat(), handle)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = if (e.x > width - pad * 1.8f && e.y > height - pad * 1.8f) 2 else 1
                lastX = e.rawX
                lastY = e.rawY
                onGestureStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                if (dx != 0 || dy != 0) {
                    lastX += dx
                    lastY += dy
                    if (mode == 2) onResize?.invoke(dx, dy) else onDrag?.invoke(dx, dy)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = 0
                onGestureEnd?.invoke()
            }
        }
        return true
    }
}

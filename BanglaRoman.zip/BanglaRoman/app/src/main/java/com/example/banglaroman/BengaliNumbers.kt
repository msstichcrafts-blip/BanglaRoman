package com.example.banglaroman

/** Bengali digits and number words (0..99 are irregular, so they come from a table). */
object BengaliNumbers {

    private val SMALL = arrayOf(
        "shunyo", "ek", "dui", "tin", "char", "panch", "chhoy", "shat", "aat", "noy",
        "dosh", "egaro", "baro", "tero", "choddo", "ponero", "sholo", "shotero", "atharo", "unish",
        "bish", "ekush", "baish", "teish", "chobbish", "pochish", "chhabbish", "shatash", "atash", "unotrish",
        "trish", "ekotrish", "battrish", "tetrish", "chouotrish", "poytrish", "chhottrish", "shaitrish", "aattrish", "unochollish",
        "chollish", "ekchollish", "beyallish", "tetallish", "chuallish", "poytallish", "chhechollish", "shatchollish", "aatchollish", "unopanchash",
        "ponchash", "ekanno", "bahanno", "tippanno", "chuanno", "ponchanno", "chhappanno", "shatanno", "aatanno", "unoshaat",
        "shaat", "ekoshotti", "bashotti", "teshotti", "choushotti", "poyshotti", "chheshotti", "shatshotti", "aatshotti", "unoshottor",
        "shottor", "ekattor", "bahattor", "tiyattor", "chuyattor", "pochattor", "chhiyattor", "shatattor", "aatattor", "unoashi",
        "ashi", "ekashi", "birashi", "tirashi", "churashi", "pochashi", "chhiyashi", "shatashi", "aatashi", "unononboi",
        "nobboi", "ekanobboi", "biranobboi", "tiranobboi", "churanobboi", "pochanobboi", "chhiyanobboi", "shatanobboi", "aatanobboi", "niranobboi"
    )

    fun isBengaliDigit(c: Char): Boolean = c in '\u09E6'..'\u09EF'

    fun toAscii(c: Char): Char = '0' + (c - '\u09E6')

    /** 82 -> "birashi", 1234 -> "ek hajar dui sho chouotrish" (Bengali lakh/koti system). */
    fun words(n: Long): String {
        if (n < 100) return SMALL[n.toInt()]
        val parts = ArrayList<String>()
        var rem = n
        val koti = rem / 10_000_000L; rem %= 10_000_000L
        if (koti > 0) parts.add(words(koti) + " koti")
        val lakh = rem / 100_000L; rem %= 100_000L
        if (lakh > 0) parts.add(words(lakh) + " lakh")
        val hajar = rem / 1_000L; rem %= 1_000L
        if (hajar > 0) parts.add(words(hajar) + " hajar")
        val sho = rem / 100L; rem %= 100L
        if (sho > 0) parts.add(SMALL[sho.toInt()] + " sho")
        if (rem > 0) parts.add(SMALL[rem.toInt()])
        return parts.joinToString(" ")
    }
}

package com.example.banglaroman

import java.text.Normalizer

/**
 * Rule-based Bengali -> casual Roman ("Banglish") transliteration.
 * Example: "তুমি কেমন আছো" -> "tumi kemon acho"
 * Bengali digits become ASCII digits plus the number word: "৮২" -> "82 (birashi)".
 */
object Romanizer {

    private const val HASANTA = '\u09CD'

    private val CONS: Map<Char, String> = mapOf(
        'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh", 'ঙ' to "ng",
        'চ' to "ch", 'ছ' to "ch", 'জ' to "j", 'ঝ' to "jh", 'ঞ' to "n",
        'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh", 'ণ' to "n",
        'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh", 'ন' to "n",
        'প' to "p", 'ফ' to "ph", 'ব' to "b", 'ভ' to "bh", 'ম' to "m",
        'য' to "j", 'র' to "r", 'ল' to "l", 'শ' to "sh", 'ষ' to "sh",
        'স' to "sh", 'হ' to "h",
        '\u09DC' to "r",   // ড়
        '\u09DD' to "rh",  // ঢ়
        '\u09DF' to "y",   // য়
        '\u09CE' to "t"    // ৎ
    )

    // Independent vowels
    private val IV: Map<Char, String> = mapOf(
        'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "i", 'উ' to "u", 'ঊ' to "u",
        'ঋ' to "ri", 'এ' to "e", 'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou"
    )

    // Vowel signs (kar)
    private val VS: Map<Char, String> = mapOf(
        '\u09BE' to "a", '\u09BF' to "i", '\u09C0' to "i", '\u09C1' to "u", '\u09C2' to "u",
        '\u09C3' to "ri", '\u09C7' to "e", '\u09C8' to "oi", '\u09CB' to "o", '\u09CC' to "ou"
    )

    /** Common words where the final "o" is pronounced. Add your own here. */
    private val EXCEPTIONS: Map<String, String> = mapOf(
        "কেন" to "keno", "যেন" to "jeno", "কত" to "koto", "যত" to "joto",
        "এত" to "eto", "তত" to "toto", "মত" to "moto", "বড়" to "boro",
        "ছোট" to "chhoto", "ভাল" to "bhalo"
    ).mapKeys { normalize(it.key) }

    private class Syl(
        var onset: String,
        var vowel: String?,
        var coda: String = "",
        var noVowel: Boolean = false,
        var cc: Int = 0
    )

    private fun normalize(t: String): String {
        var s = Normalizer.normalize(t, Normalizer.Form.NFC)
        s = s.replace("\u200D", "").replace("\u200C", "")
        s = s.replace("\u09A1\u09BC", "\u09DC")
            .replace("\u09A2\u09BC", "\u09DD")
            .replace("\u09AF\u09BC", "\u09DF")
        s = s.replace("\u09C7\u09BE", "\u09CB").replace("\u09C7\u09D7", "\u09CC")
        return s
    }

    private fun cluster(parts: List<Char>): String {
        val sb = StringBuilder()
        var k = 0
        while (k < parts.size) {
            val ch = parts[k]
            val next: Char? = if (k + 1 < parts.size) parts[k + 1] else null
            if (ch == 'ক' && next == 'ষ') { sb.append("kkh"); k += 2; continue }
            if (ch == 'জ' && next == 'ঞ') { sb.append("gy"); k += 2; continue }
            val afterHasanta = k > 0
            when {
                afterHasanta && ch == 'য' -> sb.append("y")
                afterHasanta && ch == 'ব' -> sb.append("w")
                ch == 'স' -> sb.append(if (parts.size > 1) "s" else "sh")
                ch == 'ষ' -> sb.append(if (next == 'ট' || next == 'ঠ') "s" else "sh")
                else -> sb.append(CONS[ch] ?: "")
            }
            k++
        }
        var r = sb.toString()
        if (parts.size > 1) {
            r = r.replace("ngkh", "nkh").replace("ngk", "nk").replace("ngg", "ng").replace("chch", "chh")
        }
        return r
    }

    private fun readCoda(w: String, start: Int, s: Syl): Int {
        var i = start
        while (i < w.length) {
            when (w[i]) {
                '\u0982' -> s.coda += "ng"   // ং
                '\u0981' -> s.coda += "n"    // ঁ
                '\u0983' -> { }              // ঃ (silent)
                else -> return i
            }
            i++
        }
        return i
    }

    private fun parse(w: String): List<Syl> {
        val out = ArrayList<Syl>()
        var i = 0
        val n = w.length
        while (i < n) {
            val c = w[i]
            val iv = IV[c]
            if (iv != null) {
                val s = Syl("", iv)
                i++
                i = readCoda(w, i, s)
                out.add(s)
            } else if (CONS.containsKey(c)) {
                val parts = ArrayList<Char>()
                parts.add(c)
                i++
                var nov = false
                while (i < n && w[i] == HASANTA) {
                    if (i + 1 < n && CONS.containsKey(w[i + 1])) {
                        parts.add(w[i + 1]); i += 2
                    } else {
                        nov = true; i++; break
                    }
                }
                val s = Syl(cluster(parts), null, "", nov, parts.size)
                if (c == '\u09CE') s.noVowel = true
                if (!nov && i < n) {
                    val vs = VS[w[i]]
                    if (vs != null) { s.vowel = vs; i++ }
                }
                i = readCoda(w, i, s)
                out.add(s)
            } else {
                val vs = VS[c]
                if (vs != null) {
                    val s = Syl("", vs)
                    i++
                    i = readCoda(w, i, s)
                    out.add(s)
                } else {
                    out.add(Syl(c.toString(), "", "", true, 0))
                    i++
                }
            }
        }
        return out
    }

    /** Decides where the inherent vowel "o" is pronounced and where it is dropped (schwa deletion). */
    private fun render(sy: List<Syl>): String {
        val n = sy.size
        val hasVowel = BooleanArray(n)
        val sb = StringBuilder()
        for (i in 0 until n) {
            val s = sy[i]
            val explicit = s.vowel
            val v: String = when {
                s.noVowel -> ""
                explicit != null -> explicit
                s.coda.isNotEmpty() -> "o"
                n == 1 -> "o"
                i == n - 1 -> if (s.cc >= 2) "o" else ""
                i == 0 -> "o"
                else -> {
                    val prev = hasVowel[i - 1]
                    val nx = sy[i + 1]
                    val nextHasVowel = when {
                        nx.noVowel -> false
                        nx.vowel != null -> true
                        nx.coda.isNotEmpty() -> true
                        i + 1 == n - 1 -> nx.cc >= 2
                        else -> true
                    }
                    if (s.cc == 1 && prev && nextHasVowel) "" else "o"
                }
            }
            hasVowel[i] = v.isNotEmpty()
            sb.append(s.onset).append(v).append(s.coda)
        }
        return sb.toString()
    }

    private fun romanizeWord(w: String): String = EXCEPTIONS[w] ?: render(parse(w))

    private fun isLetter(c: Char): Boolean =
        c in '\u0980'..'\u09FF' && !BengaliNumbers.isBengaliDigit(c)

    fun romanize(text: String): String {
        val t = normalize(text)
        val n = t.length
        val sb = StringBuilder()
        var i = 0
        while (i < n) {
            val c = t[i]
            if (BengaliNumbers.isBengaliDigit(c)) {
                val digits = StringBuilder()
                var hasFraction = false
                while (i < n) {
                    val d = t[i]
                    val nextIsDigit = i + 1 < n && BengaliNumbers.isBengaliDigit(t[i + 1])
                    if (BengaliNumbers.isBengaliDigit(d)) {
                        digits.append(BengaliNumbers.toAscii(d)); i++
                    } else if (d == ',' && nextIsDigit) {
                        i++
                    } else if (d == '.' && nextIsDigit) {
                        digits.append('.'); hasFraction = true; i++
                    } else break
                }
                val ascii = digits.toString()
                sb.append(ascii)
                if (!hasFraction && ascii.length <= 9) {
                    sb.append(" (").append(BengaliNumbers.words(ascii.toLong())).append(")")
                }
            } else if (isLetter(c)) {
                val start = i
                while (i < n && isLetter(t[i])) i++
                sb.append(romanizeWord(t.substring(start, i)))
            } else if (c == '\u0964' || c == '\u0965') {
                sb.append('.'); i++
            } else {
                sb.append(c); i++
            }
        }
        return sb.toString()
    }
}

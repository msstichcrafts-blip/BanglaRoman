package com.example.banglaroman

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** On-device Bengali OCR using Tesseract. The "ben" model is downloaded once on first launch. */
class OcrEngine(private val context: Context) {

    private var api: TessBaseAPI? = null

    // "fast" model = quicker (good for realtime). For more accuracy, replace "tessdata_fast" with "tessdata_best".
    private val modelUrl = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/ben.traineddata"

    suspend fun prepare(onStatus: (String) -> Unit): Boolean = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, "tessdata").apply { mkdirs() }
            val model = File(dir, "ben.traineddata")
            if (!model.exists() || model.length() < 500_000) {
                onStatus("Downloading Bengali OCR data (one time, needs internet)…")
                download(modelUrl, model)
            }
            onStatus("Loading OCR engine…")
            val t = TessBaseAPI()
            if (!t.init(context.filesDir.absolutePath, "ben")) {
                t.recycle()
                onStatus("Could not load the Bengali OCR model.")
                return@withContext false
            }
            t.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            synchronized(this@OcrEngine) { api = t }
            true
        } catch (e: Exception) {
            onStatus("OCR setup failed: ${e.message}")
            false
        }
    }

    private fun download(url: String, dest: File) {
        val tmp = File(dest.parentFile, dest.name + ".part")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        try {
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
        } finally {
            conn.disconnect()
        }
        dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("Could not save model file")
    }

    @Synchronized
    fun recognize(src: Bitmap): String {
        val t = api ?: return ""
        val prepared = preprocess(src)
        return try {
            t.setImage(prepared)
            val text = t.getUTF8Text() ?: ""
            t.clear()
            text.trim()
        } finally {
            prepared.recycle()
        }
    }

    @Synchronized
    fun release() {
        api?.let {
            try { it.stop() } catch (_: Exception) { }
            it.recycle()
        }
        api = null
    }

    /** Grayscale, auto-invert for dark backgrounds, and upscale small crops so OCR sees bigger glyphs. */
    private fun preprocess(src: Bitmap): Bitmap {
        val scale = if (maxOf(src.width, src.height) < 1000) 2f else 1f
        val w = (src.width * scale).toInt()
        val h = (src.height * scale).toInt()

        val tiny = Bitmap.createScaledBitmap(src, 16, 16, true)
        val px = IntArray(256)
        tiny.getPixels(px, 0, 16, 0, 0, 16, 16)
        if (tiny !== src) tiny.recycle()
        var sum = 0L
        for (p in px) sum += (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
        val dark = (sum / 256) < 110

        val cm = ColorMatrix().apply { setSaturation(0f) }
        if (dark) {
            cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        -1f, 0f, 0f, 0f, 255f,
                        0f, -1f, 0f, 0f, 255f,
                        0f, 0f, -1f, 0f, 255f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        Canvas(out).drawBitmap(src, null, Rect(0, 0, w, h), paint)
        return out
    }
}

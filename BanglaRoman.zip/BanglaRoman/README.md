# Bangla Romanizer (Android)

Select an area on screen; Bengali text inside it is read (OCR) and shown romanized,
e.g. `তুমি কেমন আছো` -> `tumi kemon acho`. Bengali numbers are shown as digits plus the
spoken word, e.g. `৮২` -> `82 (birashi)`, `৮১` -> `81 (ekashi)`.

## Get the APK
**Option A - Android Studio (PC):** File > Open this folder, wait for Gradle sync, plug in a phone
(USB debugging on) and press Run. Or Build > Build APK(s).

**Option B - no PC tools, free (GitHub):** create a GitHub repo, upload this project's files
(keep the folder structure, including `.github/workflows/build.yml`), open the Actions tab,
run "Build APK", then download `BanglaRoman-debug-apk` from the run and install `app-debug.apk`.

## Use
1. Open the app, tap Start, allow "Display over other apps", notifications and screen capture
   (choose "Entire screen").
2. First launch downloads the Bengali OCR model (~few MB) - internet needed once.
3. Drag the cyan box over Bengali text; resize with the corner square. Result bubble appears next to it.
4. `Lock` makes the box click-through so you can scroll/tap the app underneath. `Stop` quits.

## Notes / limits
- Portrait use is recommended; if you rotate the phone, tap Stop and Start again.
- OCR accuracy depends on font size and clarity. For better accuracy, change `tessdata_fast` to
  `tessdata_best` in `OcrEngine.kt` (slower).
- Romanization is rule-based (casual Banglish). Add words that come out wrong to `EXCEPTIONS`
  in `Romanizer.kt`.
- Apps that block screenshots (banking, some video apps) show black to any screen capture.
- If Gradle can't find `tesseract4android:4.7.0`, check the latest version on the Tesseract4Android GitHub page (it is hosted on JitPack) and bump it in `app/build.gradle.kts`.
